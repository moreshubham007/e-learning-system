<!DOCTYPE html>
<html>
<head>
  <title>E-Learning Portal</title>
</head>
<body>
  <?php include("login/login.php") ?>
</body>
</html>
