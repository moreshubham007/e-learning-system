<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="admin.css">
<link rel="stylesheet" href="ahome.css">
	<title>Admin login</title>
</head>
<body>
<div class="col-6 col-s-9">
	<div class="box">
		<h1>Admin Login</h1>
		<?php include("log.php") ?>
	</div>
</div>
</body>
</html>