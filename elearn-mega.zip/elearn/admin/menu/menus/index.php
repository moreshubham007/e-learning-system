<?php
{
    header("Location: ../../../invalid.php");
    exit();
}
?>